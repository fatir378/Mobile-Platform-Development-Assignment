package com.shahzad_raja_S1912890.rss_reader;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class Raw_Data extends AppCompatActivity {

    WebView webView;
    TextView link_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_raw_data);

        link_text = findViewById(R.id.link_text);
        webView = findViewById(R.id.webView2);

        Bundle bundle = getIntent().getExtras();
        if (bundle!=null){
            link_text.setText(bundle.getString("rssLink"));

            String url = link_text.getText().toString();

            webView.getSettings().setLoadsImagesAutomatically(true);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
            webView.loadUrl(url);
        }

    }

    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }
}