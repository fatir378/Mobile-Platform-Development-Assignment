package com.shahzad_raja_S1912890.rss_reader;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    ArrayList<String> rssLinks = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        Button btn5 = findViewById(R.id.btn5);
        Button btn6 = findViewById(R.id.btn6);
        Button btn7 = findViewById(R.id.btn7);

        Button btn1_1 = findViewById(R.id.btn1_1);
        Button btn1_2 = findViewById(R.id.btn1_2);
        Button btn1_3 = findViewById(R.id.btn1_3);
        Button btn1_4 = findViewById(R.id.btn1_4);
        Button btn1_5 = findViewById(R.id.btn1_5);
        Button btn1_6 = findViewById(R.id.btn1_6);
        Button btn1_7 = findViewById(R.id.btn1_7);


        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);

        btn1_1.setOnClickListener(this);
        btn1_2.setOnClickListener(this);
        btn1_3.setOnClickListener(this);
        btn1_4.setOnClickListener(this);
        btn1_5.setOnClickListener(this);
        btn1_6.setOnClickListener(this);
        btn1_7.setOnClickListener(this);

        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2643123");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2648579");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2643743");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/5128581");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/287286");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/934154");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/1185241");

        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2643123");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2648579");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2643743");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/5128586");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/287286");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/934154");
        rssLinks.add("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/1185241");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn1:
                startActivity(new Intent(MainActivity.this, RSSFeedActivity.class).putExtra("rssLink", rssLinks.get(0)));
                break;

            case R.id.btn2:
                startActivity(new Intent(MainActivity.this, RSSFeedActivity.class).putExtra("rssLink", rssLinks.get(1)));
                break;

            case R.id.btn3:
                startActivity(new Intent(MainActivity.this, RSSFeedActivity.class).putExtra("rssLink", rssLinks.get(2)));
                break;

            case R.id.btn4:
                startActivity(new Intent(MainActivity.this, RSSFeedActivity.class).putExtra("rssLink", rssLinks.get(3)));
                break;

            case R.id.btn5:
                startActivity(new Intent(MainActivity.this, RSSFeedActivity.class).putExtra("rssLink", rssLinks.get(4)));
                break;

            case R.id.btn6:
                startActivity(new Intent(MainActivity.this, RSSFeedActivity.class).putExtra("rssLink", rssLinks.get(5)));
                break;

            case R.id.btn7:
                startActivity(new Intent(MainActivity.this, RSSFeedActivity.class).putExtra("rssLink", rssLinks.get(6)));
                break;

            case R.id.btn1_1:
                startActivity(new Intent(MainActivity.this, Raw_Data.class).putExtra("rssLink", rssLinks.get(7)));
                break;

            case R.id.btn1_2:
                startActivity(new Intent(MainActivity.this, Raw_Data.class).putExtra("rssLink", rssLinks.get(8)));
                break;

            case R.id.btn1_3:
                startActivity(new Intent(MainActivity.this, Raw_Data.class).putExtra("rssLink", rssLinks.get(9)));
                break;

            case R.id.btn1_4:
                startActivity(new Intent(MainActivity.this, Raw_Data.class).putExtra("rssLink", rssLinks.get(10)));
                break;

            case R.id.btn1_5:
                startActivity(new Intent(MainActivity.this, Raw_Data.class).putExtra("rssLink", rssLinks.get(11)));
                break;

            case R.id.btn1_6:
                startActivity(new Intent(MainActivity.this, Raw_Data.class).putExtra("rssLink", rssLinks.get(12)));
                break;

            case R.id.btn1_7:
                startActivity(new Intent(MainActivity.this, Raw_Data.class).putExtra("rssLink", rssLinks.get(13)));
                break;
        }
    }
}
